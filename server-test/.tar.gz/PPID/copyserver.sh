#!/bin/bash

# 強制使用 UTF-8 編碼
export LANG=C.UTF-8
export LC_ALL=C.UTF-8

# 需修改 # 設定資料夾路徑 
FOLDER1="/TestAP/PPID" # 修改為PPID資料夾路徑
FOLDER2="/TestAP/Scan" # 修改為Scan資料夾路徑
PPID_FOLDER="/TestAP/PPID" # PPID.TXT 所在的資料夾(命名規則指定位址)
REMOTE_USER="Test" # server帳號
REMOTE_HOST="10.102.0.110" #server位址
REMOTE_SHARE="//10.102.0.110/ppid/SI/709-S381-L10/TEST" # 修改為要放log的位址
MOUNT_POINT="/mnt/remote_server" #掛載點(無需修改)
PASSWORD="Test123" # server密碼

# 獲取 PPID.TXT 文件內容來命名壓縮文件
MY_PPID=$(tr -d '\r' < "$PPID_FOLDER/PPID.TXT")
ARCHIVE_NAME="${MY_PPID}.tar.gz"

# 顯示壓縮文件名稱以進行調試
echo "Archive name: $ARCHIVE_NAME"

# 需修改 # 切換到根目錄 TestAP 
cd /TestAP

# 使用相對路徑打包 PPID 和 Scan
LC_ALL=C tar -czf "$ARCHIVE_NAME" "PPID" "Scan"

# 創建本地掛載點
mkdir -p $MOUNT_POINT

# 掛載遠程共享
mount -t cifs -o username=$REMOTE_USER,password=$PASSWORD $REMOTE_SHARE $MOUNT_POINT

# 檢查掛載命令的執行狀態
if [ $? -ne 0 ]; then
    echo "掛載遠程共享失敗"
    exit 1
fi

# 將文件複製到掛載點
cp "$ARCHIVE_NAME" $MOUNT_POINT

# 卸載掛載點
umount $MOUNT_POINT

# 清理本地的壓縮文件
rm "$ARCHIVE_NAME" || { echo "移除本地壓縮文件失敗"; exit 1; }

# 切換回原始目錄（如果需要）
cd -
