[Overview]
This script provide an one-click in-band firmware update tool for 
BMC, CPLD, and BIOS. Because the CPLD update requires a full AC power cycle to 
take effect, please remove the power cord after firmware finish updating.

================================================================================
[Start - run_firmware_update.sh]
Purpose:
    The run_firmware_update.sh will run the script for BMC, CPLD, and BIOS with one-click update. 	

Execution:
    a. Copy the BMC, CPLD, and BIOS image into the file of fwimg depending on different project.
	Note. The naming rule must follow the rule below: 
	   1. CPLD is SXX_RXX_vXX_XX.hpm 
	   2. BMC  is SXXKX.iXX
	   3. BIOS is ESXX.XX
	
    b. Replace the Yafuflash depending on the code base if necessary  

    c. BMC must support updating CPLD on S0 depending on the PRJ config for MSI OEM function.	

    d. Command: ./run_firmware_update.sh
	
    e. Single BIOS Command: DUAL_BIOS_EN=0 ./run_firmware_update.sh or fix DUAL_BIOS_EN in code by yourself
	
    f. The script will automatically detect DEVICE_NUM via Yafuflash tool.
     
	Note: If your CPLD_Update_Device_Collect.ini can not be got automatically, you can add by yourself.
	
	For example:
	in CPLD_Update_Device_Collect.ini, the contents are below:
	User Code: 368d0017
	User Code: 36810016
	User Code: 368X0014
	
	Thus, 368d0017 is device number = 0, 36810016 is device number = 1, and 368X0014 is device number = 2
	
	g. The CPLD updating order is SXXX1 --> S368D & S430D --> others
	
*******************************************************************
*  WARNING: After the CPLD firmware update is completed,          *
*  you MUST remove the power cord for AC cycle to activate        *
*  the new CPLD firmware version. After that,                     *
*  you can run the script again to check the version.             * 
*******************************************************************

================================================================================
[Log Files]
All script execution messages and results are saved under the Log/ folder.
If any issue occurs during execution, please copy the contents of the Log folder
and provide them to your Sales or FAE representative for troubleshooting 
assistance.
