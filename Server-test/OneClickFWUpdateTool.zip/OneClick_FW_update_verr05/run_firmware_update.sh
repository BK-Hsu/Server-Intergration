#!/usr/bin/env bash
set -euo pipefail

# Get the directory where this script is located, ensuring tools and image files can be found correctly regardless of execution directory
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" &>/dev/null && pwd)"

# Create Log directory (if it doesn't exist)
LOG_DIR="${SCRIPT_DIR}/Log"
mkdir -p "$LOG_DIR"

# Firmware image directory and file count
FWIMG_DIR="${SCRIPT_DIR}/fwimg"
if [[ ! -d "$FWIMG_DIR" ]]; then
  echo "WARNING: Firmware image directory not found: $FWIMG_DIR"
  FWIMG_FILE_COUNT=0
else
  # Count regular files (ignore subdirectories, hidden files, and Yafuflash tool binary)
  FWIMG_FILE_COUNT="$(find "$FWIMG_DIR" -maxdepth 1 -type f ! -name '.*' ! -name 'Yafuflash' ! -name 'Yafuflash*' 2>/dev/null | wc -l | tr -d ' ')"
fi

# Remove all Tmp_* files under script directory (ignore if none)
rm -f "${SCRIPT_DIR}"/Tmp_* 2>/dev/null || true

# ==========================
# Basic Parameter Settings
# ==========================
TOOL="${SCRIPT_DIR}/Yafuflash"                         # Yafuflash tool

# Auto-detect BMC image in fwimg: pattern *K*.i* or *k*.i*
shopt -s nullglob
BMC_FILES=("${FWIMG_DIR}"/*[Kk]*.i*)
if (( ${#BMC_FILES[@]} == 0 )); then
  shopt -u nullglob
  echo -e "\e[31m[Error] No BMC image file to found, and the name of BMC should be *K*.i* or *k*.i*\e[0m"
  die "No BMC image file matching *K*.i* or *k*.i* found in ${FWIMG_DIR}"
fi
IMG_BMC="${BMC_FILES[0]}"                              # BMC image file (non-interactive)

# Derive EXPECT_BMC_VER_BYTES from IMG_BMC filename pattern "KX.iO" or "kX.iO"
# Example full name: S4050011K1.i14.ima or S4050011k1.iAF.ima
#   -> we first extract "K1.i14" or "k1.iAF"
#   -> EXPECT_BMC_VER_BYTES=("01" "14") or ("01" "AF")
BMC_BASENAME="$(basename "$IMG_BMC")"
if [[ "$BMC_BASENAME" =~ ([Kk][0-9A-Fa-f]+\.i[0-9A-Fa-f]+) ]]; then
  BMC_KI_PART="${BASH_REMATCH[1]}"         # e.g. "K1.i14" or "k1.iAF"
else
  shopt -u nullglob
  die "Unable to find KX.iO or kX.iO pattern in BMC filename: $BMC_BASENAME"
fi

if [[ "$BMC_KI_PART" =~ [Kk]([0-9A-Fa-f]+)\.i([0-9A-Fa-f]+) ]]; then
  BMC_K_VAL="${BASH_REMATCH[1]}"
  BMC_VER_VAL="${BASH_REMATCH[2]}"
  # K value is decimal → convert to hex; i value is already hex (e.g. i14 → 0x14, iAF → 0xAF)
  EXPECT_BMC_VER_BYTES=(
    "$(printf '%02X' "$BMC_K_VAL")"
    "$(tr '[:lower:]' '[:upper:]' <<< "$BMC_VER_VAL")"
  )
else
  shopt -u nullglob
  die "Unable to extract BMC version bytes from pattern KX.iO or kX.iO: $BMC_KI_PART"
fi

# Auto-detect BIOS image in fwimg: pattern ES*.*
BIOS_FILES=("${FWIMG_DIR}"/ES*.*)
shopt -u nullglob
if (( ${#BIOS_FILES[@]} == 0 )); then
  echo -e "\e[31m[Error] No BIOS image file to found, and the name of BIOS should be ES*.*\e[0m"
  die "No BIOS image file matching ES*.* found in ${FWIMG_DIR}"
fi
IMG_BIOS="${BIOS_FILES[0]}"                            # BIOS image file (non-interactive, no tmp)

# Derive EXPECT_BIOS_VER from IMG_BIOS filename
# Example filename: ES405IMS.N09 -> EXPECT_BIOS_VER="45 53 34 30 35 49 4D 53 2E 4E 30 39"
BIOS_BASENAME="$(basename "$IMG_BIOS")"
# Remove common file extensions if present (e.g., .bin, .rom, .ima, etc.)
# But preserve version-like patterns (e.g., .N09)
if [[ "$BIOS_BASENAME" =~ \.(bin|rom|ima|exe)$ ]]; then
  BIOS_NAME_NO_EXT="${BIOS_BASENAME%.*}"
else
  BIOS_NAME_NO_EXT="$BIOS_BASENAME"
fi
# Take first 12 characters (or all if less than 12)
BIOS_NAME_12CHARS="${BIOS_NAME_NO_EXT:0:12}"
# Convert each character to hex and join with spaces
EXPECT_BIOS_VER=""
for ((i=0; i<${#BIOS_NAME_12CHARS}; i++)); do
  CHAR="${BIOS_NAME_12CHARS:$i:1}"
  HEX_VAL="$(echo -n "$CHAR" | od -An -tx1 | tr -d ' \n' | tr '[:lower:]' '[:upper:]')"
  if [[ -z "$EXPECT_BIOS_VER" ]]; then
    EXPECT_BIOS_VER="$HEX_VAL"
  else
    EXPECT_BIOS_VER="$EXPECT_BIOS_VER $HEX_VAL"
  fi
done
# Auto-detect CPLD HPM images in fwimg and derive expected CPLD version from each filename.
# Example filename: S4051_R0N_v09_0x8587_20250616.hpm -> S4051_RXX_v09_XXX.hpm -> EXPECT_CPLD_VER="09 00 51 40"
shopt -s nullglob
HPM_FILES=("${FWIMG_DIR}"/*.hpm)
shopt -u nullglob
if (( ${#HPM_FILES[@]} == 0 )); then
  echo -e "\e[31m[Error] No CPLD image file to found, and the name of CPLD should be SOOOO_RXX_vOO_XX.hpm\e[0m"
  die "No .hpm CPLD image file found in ${FWIMG_DIR}"
fi

# Initialize arrays to store multiple CPLD images and their expected versions
IMG_CPLD=()
EXPECT_CPLD_VER=()
DECIDE_BYTES=()
DECIDE_BYTES_SEC=()
filecount=0
# Process each HPM file to extract version information
for hpm_file in "${HPM_FILES[@]}"; do
  IMG_CPLD+=("$hpm_file")
  HPM_BASENAME="$(basename "$hpm_file")"

  # Extract first byte from pattern _vXX_
  if [[ "$HPM_BASENAME" =~ _v([0-9A-Fa-f]{2})_ ]]; then
    CPLD_VER_BYTE="${BASH_REMATCH[1]}"
    CPLD_VER_BYTE_UPPER="$(tr '[:lower:]' '[:upper:]' <<< "$CPLD_VER_BYTE")"
  else
    die "Unable to extract CPLD major version (vXX) from HPM filename: $HPM_BASENAME"
  fi

  # Extract board code (4 hex digits after leading 'S' or 's', e.g. S4051/s4051 -> 40 51)
  HPM_BASENAME_UPPER="$(tr '[:lower:]' '[:upper:]' <<< "$HPM_BASENAME")"
  if [[ "$HPM_BASENAME_UPPER" =~ ^S([0-9A-Fa-f]{4})_ ]]; then
    BOARD_HEX="${BASH_REMATCH[1]}"
    BOARD_HEX_UPPER="$(tr '[:lower:]' '[:upper:]' <<< "$BOARD_HEX")"
    CPLD_VER_BYTE_2nd="00"
    CPLD_VER_BYTE_3rd="${BOARD_HEX_UPPER:2:2}"  # low byte, e.g. 51
    CPLD_VER_BYTE_4th="${BOARD_HEX_UPPER:0:2}"  # high byte, e.g. 40
  else
    die "Unable to extract board code (SXXXX_) from HPM filename: $HPM_BASENAME"
  fi

  EXPECT_CPLD_VER+=("${CPLD_VER_BYTE_UPPER} ${CPLD_VER_BYTE_2nd} ${CPLD_VER_BYTE_3rd} ${CPLD_VER_BYTE_4th}")
  
  #To read detect version firstly
  read -ra decide_bytes <<< "${EXPECT_CPLD_VER[$filecount]}"
  DECIDE_BYTES[$filecount]="${decide_bytes[2]:-XX}"
  #echo "  DECIDE_BYTES[$filecount]=${DECIDE_BYTES[$filecount]}"
  read -ra decide_bytes_sec <<< "${EXPECT_CPLD_VER[$filecount]}"
  DECIDE_BYTES_SEC[$filecount]="${decide_bytes_sec[3]:-XX}"
  #echo "  DECIDE_BYTES_SEC[$filecount]=${DECIDE_BYTES_SEC[$filecount]}"
  filecount=$((filecount+1))
done

CPLD_COUNT=${#IMG_CPLD[@]}
echo "========================================"
echo "All Firmware Information"
echo "========================================"
echo "Firmware image directory      : $FWIMG_DIR"
echo "Number of files in fwimg      : $FWIMG_FILE_COUNT"
echo "Detected BMC image            : $IMG_BMC"
#echo "Derived EXPECT_BMC_VER_BYTES  : ${EXPECT_BMC_VER_BYTES[*]}"
echo "Number of CPLD images         : $CPLD_COUNT"
for ((i=0; i<CPLD_COUNT; i++)); do
  echo "  CPLD$((i+1)) image            : ${IMG_CPLD[$i]}"
  #echo "  CPLD$((i+1)) expected version : ${EXPECT_CPLD_VER[$i]}"
done
echo "Detected BIOS image           : $IMG_BIOS"
#echo "Derived EXPECT_BIOS_VER value : $EXPECT_BIOS_VER"
echo "========================================"
echo
echo "Start to update at $(date +%T)"
echo "Wait 5 sec here. Please check All firmware information which is correct or not, or CTRL-C to cancel"
echo
sleep 5

READ_RETRY=3                                           # Number of retries for reading CPLD version
READ_INTERVAL=2                                        # Interval in seconds between retries
ENABLE_POWER_OFF=0                                     # Enable (1) or disable (0) power off after CPLD update
DUAL_BIOS_EN="${DUAL_BIOS_EN:-1}"                      # Enable (1) or disable (0) dual BIOS update for DCSCM. Single mode Command: DUAL_BIOS_EN=0 ./run_firmware_update.sh
	
# Single unified log (covers all output)
LOG="${LOG_DIR}/FW_update_$(date +%Y%m%d_%H%M%S).log"

# Redirect all script stdout/stderr to display and write to a single log
exec > >(tee -a "$LOG") 2>&1

# Error handling function
die() { echo "ERROR: $*" >&2; exit 1; }

# ==========================
# Environment and File Checks Before Execution
# ==========================
command -v ipmitool >/dev/null 2>&1 || die "ipmitool not found. Please install it: sudo apt install -y ipmitool"
[[ -x "$TOOL" ]] || die "Yafuflash not found or not executable: $TOOL"
[[ -f "$IMG_BMC" ]] || die "BMC image file not found: $IMG_BMC"
[[ -f "$IMG_BIOS" ]] || die "BIOS image file not found: $IMG_BIOS"
for ((i=0; i<CPLD_COUNT; i++)); do
  [[ -f "${IMG_CPLD[$i]}" ]] || die "CPLD image file not found: ${IMG_CPLD[$i]}"
done

# ------------------------------------------------------
# Function: Read CPLD version (last four bytes)
# Parameter: cpld_index - 1-based index of the CPLD (1 for first, 2 for second, etc.)
# Uses formula: tail -n (4 + 63*(cpld_index - 1))
# ------------------------------------------------------
read_cpld_version() {
  local cpld_index="${1:-1}"  # Default to 1 if not provided
  local tail_lines=$((4 + 63 * (cpld_index - 1)))
  
  sudo ipmitool raw 0x32 0xd6 0x00 2>/dev/null \
    | grep -Eo '\b[0-9A-Fa-f]{2}\b' \
    | tail -n "$tail_lines" \
    | tr '\n' ' ' \
    | sed -E 's/[[:space:]]+$//' \
    | tr '[:lower:]' '[:upper:]' \
    | cut -d' ' -f1-4
}

real_cpld_count() {
	sudo ipmitool raw 0x32 0xd6 0x00 2>/dev/null \
	  | head -n 1 \
	  | cut -d ' ' -f 2
}

# ------------------------------------------------------
# Function: Check if current BMC version matches EXPECT_BMC_VER_BYTES
# Returns:
#   - 0 (success) if BMC version matches expected bytes
#   - 1 (failure) otherwise
# ------------------------------------------------------
check_bmc_version_ok() {
  local bytes
  mapfile -t bytes < <(sudo ipmitool raw 0x06 0x01 2>/dev/null | grep -Eo '\b[0-9A-Fa-f]{2}\b' | tr '[:lower:]' '[:upper:]')
  if (( ${#bytes[@]} < 8 )); then
    return 1
  fi

  local b3="${bytes[2]:-XX}"
  local b4="${bytes[3]:-XX}"

  if [[ "$b3" == "${EXPECT_BMC_VER_BYTES[0]}" && "$b4" == "${EXPECT_BMC_VER_BYTES[1]}" ]]; then
    # Version matches expected
    return 0
  fi

  # Version does not match expected
  return 1
}

# ------------------------------------------------------
# Function: Read BIOS version (12 bytes starting from byte 5)
# If successful, returns format like "45 53 34 32 35 41 4D 53 2E 4D 30 37"
# ------------------------------------------------------
read_bios_version_12bytes() {
  local bytes arr
  mapfile -t arr < <(sudo ipmitool raw 0x06 0x59 0x00 0x01 0x00 0x00 2>/dev/null | grep -Eo '\b[0-9A-Fa-f]{2}\b' | tr '[:lower:]' '[:upper:]')
  if (( ${#arr[@]} < 16 )); then
    return 1
  fi
  bytes=("${arr[@]:4:12}")
  printf '%s ' "${bytes[@]}" | sed -E 's/[[:space:]]+$//'
  return 0
}

# ------------------------------------------------------
# Main Program Starts
# ------------------------------------------------------
echo
echo "========================================"
echo "[0/6] CPLD & BMC & BIOS Update Script"
echo "========================================"
echo "Tool      : $TOOL"
echo "BMC IMG   : $IMG_BMC"
echo "BIOS IMG  : $IMG_BIOS"
echo "CPLD IMGs : $CPLD_COUNT file(s)"
for ((i=0; i<CPLD_COUNT; i++)); do
  echo "  CPLD$((i+1))  : ${IMG_CPLD[$i]}"
done
echo "Log File  : $LOG"
echo "----------------------------------------"

# Request user to enter sudo password (system will prompt automatically)
sudo -v || die "sudo authentication failed. Please check your password and permissions."

# Step 0: Capture baseline BIOS version before any BMC update (because BMC update will clear boot information)
#echo "Reading current BIOS version (before any BMC update)..."
BASELINE_BIOS_VER="$(read_bios_version_12bytes || true)"
#echo "BIOS version: $BASELINE_BIOS_VER"
if [[ -z "${BASELINE_BIOS_VER:-}" ]]; then
  echo "WARNING: Unable to read BIOS version from ipmitool. Will proceed, and BIOS update will be performed as needed. Please install ipmitool firstly"
fi


# Step 1: Verify BMC version, update only if it doesn't match (using -non-interactive)
echo "[1/6] Checking current BMC version..."
if check_bmc_version_ok; then
  echo -e "\e[33mBMC version is already up-to-date so skipping BMC update.\e[0m"
else
  echo "BMC version NOT as expected. Starting BMC firmware update, please wait..."
  echo "Wait 5 sec to start BMC update, or CTRL-C to cancel"
  sleep 5
  # Temporarily disable -e to prevent Yafuflash non-zero exit code from stopping the script
  set +e
  TMP_OUT="$(mktemp)"
  sudo "$TOOL" -cd -mse 3 -non-interactive "$IMG_BMC" 2>&1 | tee "$TMP_OUT"
  YAFU_RC=${PIPESTATUS[0]}
  set -e

  # Detect "Device already in firmware update mode"
  if grep -qi "Device already in firmware update mode" "$TMP_OUT"; then
    echo "******************************************************************************"
    echo "* ERROR: BMC is already in firmware update mode.                             *"
    echo "* If you performed the CPLD update but did not do an AC power cycle,         *"
    echo "* you may see this message. Please perform an AC power cycle and retry.      *"
    echo "* If you have already done the AC cycle and still see this message,          *"
    echo "* please contact your Sales or FAE.                                          *"
    echo "******************************************************************************"
    rm -f "$TMP_OUT"
    exit 4
  fi
  rm -f "$TMP_OUT"

  echo "----------------------------------------"
  if [[ $YAFU_RC -ne 0 ]]; then
    echo "Yafuflash (BMC) exited with code: $YAFU_RC"
    exit $YAFU_RC
  fi
  echo -e "\e[32mYafuflash (BMC) finished successfully (exit code 0).\e[0m"
  echo "Waiting 180 seconds for BMC to settle before re-checking version..."
  sleep 180

  echo "Re-checking BMC version after update..."
  if check_bmc_version_ok; then
    echo -e "\e[32mSUCCESS: BMC update completed and the version is the same as expected BMC version.\e[0m"
  else
    echo -e "\e[31mBMC update failed, please run script again.\e[0m"
    echo -e "\e[31mIf BMC update always failed, please contact your Sales/FAE.\e[0m"
    exit 3
  fi
fi

# Step 2: Check and update CPLD

read_cpld_version_with_retry() {
  local cpld_index="${1:-1}"  # Default to 1 if not provided
  local out=""
  for ((i=1; i<=READ_RETRY; i++)); do
    out="$(read_cpld_version "$cpld_index" || true)"
    if [[ -n "$out" && "$(wc -w <<<"$out")" -eq 4 ]]; then
      echo "$out"
      return 0
    fi
    echo "Failed to read CPLD version (attempt $i/$READ_RETRY), retrying in ${READ_INTERVAL}s..."
    sleep "$READ_INTERVAL"
  done
  return 1
}

echo "========================================"
echo " [4/6] CPLD Update Section"
echo "========================================"
echo "Tool       : $TOOL"
echo "CPLD file Count : $CPLD_COUNT"
echo "Log File   : $LOG"
echo "----------------------------------------"

sudo -v || die "sudo authentication failed. Please check your password and permissions."

# First, read all available CPLD versions from the system
echo "Reading all CPLD versions from the system..."
DETECTED_CPLD_VERS=()
DETECTED_CPLD_COUNT=0

# Get real CPLD count from BMC/IPMI (ipmitool raw 0x32 0xd6 0x00)
RAW_CPLD_COUNT="$(real_cpld_count 2>/dev/null || true)"
if [[ -n "$RAW_CPLD_COUNT" ]]; then
  # RAW_CPLD_COUNT is usually a hex byte (e.g. 03), convert to decimal
  if [[ "$RAW_CPLD_COUNT" =~ ^[0-9A-Fa-f]+$ ]]; then
    MAX_CPLD_TO_CHECK=$((16#$RAW_CPLD_COUNT))
  else
    MAX_CPLD_TO_CHECK="$RAW_CPLD_COUNT"
  fi
else
  MAX_CPLD_TO_CHECK=3
fi

# Safety clamp: we only expect up to 3 CPLDs on this platform
if (( MAX_CPLD_TO_CHECK > 3 )); then
  MAX_CPLD_TO_CHECK=3
fi

for ((cpld_idx=1; cpld_idx<=MAX_CPLD_TO_CHECK; cpld_idx++)); do
  CPLD_VER_READ="$(read_cpld_version_with_retry "$cpld_idx" 2>/dev/null || true)"
  if [[ -n "$CPLD_VER_READ" && "$(wc -w <<<"$CPLD_VER_READ")" -eq 4 ]]; then
    DETECTED_CPLD_VERS+=("$CPLD_VER_READ")
    DETECTED_CPLD_COUNT=$((DETECTED_CPLD_COUNT + 1))
    echo "  Detected CPLD$cpld_idx version: $CPLD_VER_READ"
  else
    # No more CPLDs found, stop checking
    break
  fi
done



if [[ $DETECTED_CPLD_COUNT -eq 0 ]]; then
  die "No CPLD versions detected from the system. Please check BMC/IPMI status and permissions."
fi

echo "Total detected CPLDs in system: $DETECTED_CPLD_COUNT"
echo "----------------------------------------"

# Sort CPLD update order based on DECIDE_BYTES priority:
# Priority 1: (DECIDE_BYTES[$i] & 0x01) != 0 (bit 0 is set, but not matching 0x0D)
# Priority 2: (DECIDE_BYTES[$i] & 0x0D) == 0x0D (bits 0, 2, 3 all set)
# Priority 3: All remaining files
CPLD_UPDATE_ORDER=()
# First pass: Add items matching last hex digit "1" but NOT 0x0D (Priority 1)
for ((i=0; i<CPLD_COUNT; i++)); do
  if [[ -n "${DECIDE_BYTES[$i]}" && "${DECIDE_BYTES[$i]}" != "XX" ]]; then
    # Convert to uppercase for case-insensitive comparison
    decide_bytes_val="${DECIDE_BYTES[$i]^^}"
    # Check if last hex digit is "1" (matches 01, 11, 21, 31, 41, 51, 61, 71, 81, 91, A1, B1, C1, D1, E1, F1)
    # Note: 0x0D (0D in hex) ends in "D", not "1", so it will never match this condition
    if [[ "${decide_bytes_val: -1}" == "1" ]]; then
      CPLD_UPDATE_ORDER+=("$i")
    fi
  fi
done
# Second pass: Add items matching Priority 2 rule: merged_string == "368D" or "430D"
for ((i=0; i<CPLD_COUNT; i++)); do
  if [[ -n "${DECIDE_BYTES[$i]}" && "${DECIDE_BYTES[$i]}" != "XX" && -n "${DECIDE_BYTES_SEC[$i]}" && "${DECIDE_BYTES_SEC[$i]}" != "XX" ]]; then
    # Convert to uppercase for case-insensitive string comparison
    decide_val_str="${DECIDE_BYTES[$i]^^}"
    decide_val_sec_str="${DECIDE_BYTES_SEC[$i]^^}"
    merged_string="$decide_val_sec_str$decide_val_str"
    # Check: merged_string == "368D" or "430D"
    if [[ "$merged_string" == "368D" || "$merged_string" == "430D" ]]; then
      # Check if not already added
      already_added=0
      for idx in "${CPLD_UPDATE_ORDER[@]}"; do
        if [[ "$idx" == "$i" ]]; then
          already_added=1
          break
        fi
      done
      if [[ $already_added -eq 0 ]]; then
        CPLD_UPDATE_ORDER+=("$i")
      fi
    fi
  fi
done
# Third pass: Add all remaining items
for ((i=0; i<CPLD_COUNT; i++)); do
  already_added=0
  for idx in "${CPLD_UPDATE_ORDER[@]}"; do
    if [[ "$idx" == "$i" ]]; then
      already_added=1
      break
    fi
  done
  if [[ $already_added -eq 0 ]]; then
    CPLD_UPDATE_ORDER+=("$i")
  fi
done

echo "CPLD update order (based on DECIDE_BYTES priority):"
for ((order_idx=0; order_idx<${#CPLD_UPDATE_ORDER[@]}; order_idx++)); do
  i="${CPLD_UPDATE_ORDER[$order_idx]}"
  echo "  Order $((order_idx+1)): Image $((i+1)) (DECIDE_BYTES[$i]=${DECIDE_BYTES[$i]:-XX})"
done
echo "----------------------------------------"

# Update each CPLD firmware in the determined order
CPLD_UPDATE_NEEDED=0
for order_idx in "${!CPLD_UPDATE_ORDER[@]}"; do
  i="${CPLD_UPDATE_ORDER[$order_idx]}"
  echo
  echo "----------------------------------------"
  echo "Processing CPLD image $((order_idx+1)) of ${#CPLD_UPDATE_ORDER[@]} (Image index: $((i+1)), DECIDE_BYTES[$i]=${DECIDE_BYTES[$i]:-XX})"
  echo "----------------------------------------"
  echo "Image      : ${IMG_CPLD[$i]}"
  echo "Target Ver : ${EXPECT_CPLD_VER[$i]}"
  
  # Extract expected board ID bytes (3rd and 4th) from the image
  read -ra exp_bytes <<< "${EXPECT_CPLD_VER[$i]}"
  exp_b3="${exp_bytes[2]:-YY}"
  exp_b4="${exp_bytes[3]:-YY}"
  # Try to find a matching CPLD in the system by checking all detected CPLD versions
  MATCHED_CPLD_INDEX=-1
  MATCHED_CPLD_VER=""
  for ((j=0; j<DETECTED_CPLD_COUNT; j++)); do
    read -ra cur_bytes <<< "${DETECTED_CPLD_VERS[$j]}"
    cur_b3="${cur_bytes[2]:-XX}"
    cur_b4="${cur_bytes[3]:-XX}"
    
    if [[ "$cur_b3" == "$exp_b3" && "$cur_b4" == "$exp_b4" ]]; then
      MATCHED_CPLD_INDEX=$((j+1))
      MATCHED_CPLD_VER="${DETECTED_CPLD_VERS[$j]}"
      echo "Found matching CPLD$MATCHED_CPLD_INDEX: board ID bytes (3rd,4th) = $cur_b3 $cur_b4"
      break
    fi
  done
  
  if [[ $MATCHED_CPLD_INDEX -eq -1 ]]; then
    echo -e "\e[31mERROR: No matching CPLD found in system for image ${IMG_CPLD[$i]}\e[0m"
    echo "       Expected board ID bytes (3rd,4th): $exp_b3 $exp_b4"
    echo "       Detected CPLD board IDs:"
    for ((j=0; j<DETECTED_CPLD_COUNT; j++)); do
      read -ra cur_bytes <<< "${DETECTED_CPLD_VERS[$j]}"
      cur_b3="${cur_bytes[2]:-XX}"
      cur_b4="${cur_bytes[3]:-XX}"
      echo "         CPLD$((j+1)): $cur_b3 $cur_b4"
    done
    echo -e "       \e[33mSkipping this CPLD image update.\e[0m"
    continue
  fi
  
  echo "Current CPLD$MATCHED_CPLD_INDEX Version: $MATCHED_CPLD_VER"

  if [[ "$MATCHED_CPLD_VER" == "${EXPECT_CPLD_VER[$i]}" ]]; then
    echo "CPLD$MATCHED_CPLD_INDEX version (${EXPECT_CPLD_VER[$i]}) is already installed. Skipping update."
  else
    CPLD_UPDATE_NEEDED=1
    echo "CPLD$MATCHED_CPLD_INDEX version differs from expected."
    echo "  - Current: $MATCHED_CPLD_VER"
    echo "  - Expected: ${EXPECT_CPLD_VER[$i]}"
    
    if [[ $CPLD_UPDATE_NEEDED -eq 1 && $order_idx -eq 0 ]]; then
      # Show power off message only for the first CPLD update
      if [[ "${ENABLE_POWER_OFF:-1}" -eq 1 ]]; then
        echo "After CPLD firmware update, the system will shutdown automatically."
        echo "After that, please perform an AC power cycle (remove power cord) to let the CPLD FW take effect."
      else
        echo "Power off is disabled (ENABLE_POWER_OFF=0). Please manually power off the system and remove the power cord after updating finish."
        echo "After powering on the system, please run the script again to check versions"
      fi
    fi
    
    if [[ $order_idx -eq 0 ]]; then
      echo "Wait 5 sec to start CPLD update, or CTRL-C to cancel"
      sleep 5
    else
      echo "Wait 3 sec before updating next CPLD..."
      sleep 3
    fi
    echo "Stop all sensors ..."
	sudo ipmitool raw 0x28 0x41 1 0 
	sleep 1

    # Run CPLD update and save output to a dedicated text log file
    CPLD_LOG="${FWIMG_DIR}/CPLD_Update_Device_Collect.ini"
    RC=0
    if [ ! -f "$CPLD_LOG" ]; then
	  echo "CPLD_Update_Device_Collect.ini is not exist so run the Yafuflash once to get the ini file"
      set +e
	  echo "Starting CPLD$MATCHED_CPLD_INDEX firmware update... (log: $CPLD_LOG)"
      {
        printf '99 \n'
      } |	sudo "$TOOL" -cd -non-interactive -d 4 "${IMG_CPLD[$i]}" 2>&1 | tee -a "$CPLD_LOG"
	  RC=${PIPESTATUS[0]}
	  echo "Please ignore "Error in CPLD Update ..." above because the CPLD_Update_Device_Collect.ini is not exist. We run Yafuflash once to get ini"
	  echo "Wait 3 sec to restart to update CPLD again"
	  sleep 3
      set -e
    else
      echo "CPLD update ini already exists at $CPLD_LOG, skipping ini collect."
    fi
	
    # Read up to 3 "User Code" lines and extract 4 bytes from each
    if [ -f "$CPLD_LOG" ]; then
      mapfile -t USER_CODE_LINES < <(grep -i "User Code" "$CPLD_LOG" | head -3)

      USER_CODE_COUNT=${#USER_CODE_LINES[@]}

      # Initialize variables empty
      USER1_B1= USER1_B2= USER1_B3= USER1_B4=
      USER2_B1= USER2_B2= USER2_B3= USER2_B4=
      USER3_B1= USER3_B2= USER3_B3= USER3_B4=

      if (( USER_CODE_COUNT >= 1 )); then
        # Extract 8 hex digits from "User Code: 368d0017" format and split into 4 bytes
        USER_CODE_1=$(echo "${USER_CODE_LINES[0]}" | grep -oE '[0-9a-fA-F]{8}' | head -1)
        if [[ -n "$USER_CODE_1" && ${#USER_CODE_1} -eq 8 ]]; then
          USER1_B1="${USER_CODE_1:0:2}"
          USER1_B2="${USER_CODE_1:2:2}"
          USER1_B3="${USER_CODE_1:4:2}"
          USER1_B4="${USER_CODE_1:6:2}"
        fi
      fi

      if (( USER_CODE_COUNT >= 2 )); then
        USER_CODE_2=$(echo "${USER_CODE_LINES[1]}" | grep -oE '[0-9a-fA-F]{8}' | head -1)
        if [[ -n "$USER_CODE_2" && ${#USER_CODE_2} -eq 8 ]]; then
          USER2_B1="${USER_CODE_2:0:2}"
          USER2_B2="${USER_CODE_2:2:2}"
          USER2_B3="${USER_CODE_2:4:2}"
          USER2_B4="${USER_CODE_2:6:2}"
        fi
      fi

      if (( USER_CODE_COUNT >= 3 )); then
        USER_CODE_3=$(echo "${USER_CODE_LINES[2]}" | grep -oE '[0-9a-fA-F]{8}' | head -1)
        if [[ -n "$USER_CODE_3" && ${#USER_CODE_3} -eq 8 ]]; then
          USER3_B1="${USER_CODE_3:0:2}"
          USER3_B2="${USER_CODE_3:2:2}"
          USER3_B3="${USER_CODE_3:4:2}"
          USER3_B4="${USER_CODE_3:6:2}"
        fi
      fi

      # Optional: debug print
      echo "UserCode1: $USER1_B1 $USER1_B2 $USER1_B3 $USER1_B4"
      echo "UserCode2: $USER2_B1 $USER2_B2 $USER2_B3 $USER2_B4"
      echo "UserCode3: $USER3_B1 $USER3_B2 $USER3_B3 $USER3_B4"
    else
      echo "WARNING: CPLD_LOG file not found: $CPLD_LOG"
    fi
	
    # To do to match UserCode1 or UserCode2 or UserCode3 with expected board ID (exp_b3/exp_b4)
    DEVICE_NUM=99
    # Compare case-insensitively by forcing both sides to uppercase
    if [[ "${USER1_B2^^}" == "${exp_b3^^}" && "${USER1_B1^^}" == "${exp_b4^^}" ]]; then
      DEVICE_NUM=0
    elif [[ "${USER2_B2^^}" == "${exp_b3^^}" && "${USER2_B1^^}" == "${exp_b4^^}" ]]; then
      DEVICE_NUM=1
    elif [[ "${USER3_B2^^}" == "${exp_b3^^}" && "${USER3_B1^^}" == "${exp_b4^^}" ]]; then
      DEVICE_NUM=2
    fi
    
    if (( DEVICE_NUM <= 2 )); then
      echo "----------------------------------------"
	  echo -e "\e[32mDevice Number = $DEVICE_NUM to update\e[0m"
	  echo "File usage = ${IMG_CPLD[$i]}"
      echo "----------------------------------------"	  
      echo "Starting CPLD$MATCHED_CPLD_INDEX firmware update... (log: $CPLD_LOG)"
      {
        printf '%d\n' "$DEVICE_NUM"
      } | sudo "$TOOL" -cd -non-interactive -d 4 "${IMG_CPLD[$i]}"
    else
      echo -e "\e[31m[Error] Please check your CPLD_Update_Device_Collect.ini data\e[0m"
    fi
    
	sleep 1
	echo "Start all sensors ..."
	sudo ipmitool raw 0x28 0x41 1 1
	sleep 1

    echo "----------------------------------------"
    if [[ $RC -ne 0 ]]; then
      echo "Yafuflash (CPLD$MATCHED_CPLD_INDEX) exited with code: $RC"
      echo "Please check the log: $LOG"
      exit $RC
    fi

    echo "CPLD$MATCHED_CPLD_INDEX firmware update process completed successfully (exit code 0)."
  fi
done

# Handle power off after all CPLD updates (if any update was needed)
if [[ $CPLD_UPDATE_NEEDED -eq 1 ]]; then
  if [[ "${ENABLE_POWER_OFF:-1}" -eq 1 ]]; then
    echo
    echo -e "\e[32mAll CPLD firmware updates completed.\e[0m"
    echo "Wait 10 sec, and start to power off the system, and then please remove the power cord"
    echo "After powering on the system, please run the script again to update BIOS version"
    sleep 10
    sudo ipmitool chassis power off || echo "Power off the system..."
  else
    echo
    echo -e "\e[32mAll CPLD firmware updates completed.\e[0m"
    echo "Power off is disabled (ENABLE_POWER_OFF=0). Please manually power off the system and remove the power cord after update finish."
    echo "After powering on the system, please run the script again to check versions"
  fi
else
  echo
  echo -e "\e[33mAll CPLD firmware versions are already up-to-date. No update needed.\e[0m"
fi  

echo "========================================"
echo " [5/6] BIOS Update Section"
echo "========================================"
echo "Tool      : $TOOL"
echo "Image     : $IMG_BIOS"
echo "Target Ver: $EXPECT_BIOS_VER"
echo "Log File  : $LOG"
echo "----------------------------------------"

# Step 3: Determine whether to update based on previously captured baseline BIOS version
echo "Deciding whether BIOS update is needed based on baseline BIOS version..."
if [[ -z "${BASELINE_BIOS_VER:-}" ]]; then
  echo "Baseline BIOS version is unavailable; will proceed with BIOS update as a precaution."
  NEED_BIOS_UPDATE=1
else
  if [[ "$BASELINE_BIOS_VER" == "$EXPECT_BIOS_VER" ]]; then
    echo "BIOS is already the expected version: $BASELINE_BIOS_VER . Skip update."
    NEED_BIOS_UPDATE=0
  else
    echo "BIOS version differs from expected."
    echo "  - Baseline: $BASELINE_BIOS_VER"
    echo "  - Expected: $EXPECT_BIOS_VER"
    NEED_BIOS_UPDATE=1
  fi
fi

# Step 5: Execute BIOS update (if needed)
if [[ "${NEED_BIOS_UPDATE:-0}" -eq 1 ]]; then
  #For S425 BIOS update
  #echo "Pre-condition command before BIOS update (ipmitool raw 0x28 0x52 0x06 0x60 0x00 0x0B 0x40)..."
  #sudo ipmitool raw 0x28 0x52 0x06 0x60 0x00 0x0B 0x40 || echo "NOTE: Pre-condition command returned non-zero; continuing."

  #echo "Sleeping 1 second..."
  #sleep 1

  echo "Current version: $BASELINE_BIOS_VER -> Target version: $EXPECT_BIOS_VER"
  echo "Wait 5 sec to start BIOS update, or CTRL-C to cancel"
  sleep 5
  echo "Stop all sensors ..."
  sudo ipmitool raw 0x28 0x41 1 0 
  sleep 1  
  # BIOS update flow (single or dual BIOS for DCSCM, controlled by DUAL_BIOS_EN)
  if [[ "$DUAL_BIOS_EN" -eq 1 ]]; then
    echo "Dual BIOS mode enabled (DUAL_BIOS_EN=1)."
    echo "Starting Update BIOS image1, please wait..."
	sleep 3
    sudo "$TOOL" -cd -d 2 -non-interactive "$IMG_BIOS"
    sleep 3
    echo "Starting Update BIOS image2, please wait..."
    sudo ipmitool raw 0x28 0x0a 0x10 0x01
    sleep 10
    sudo "$TOOL" -cd -d 2 -non-interactive "$IMG_BIOS"
  else
    echo "Starting BIOS update (single image), please wait..."
	sleep 3
    sudo "$TOOL" -cd -d 2 -non-interactive "$IMG_BIOS"
  fi

  sleep 1
  echo "Start all sensors ..."
  sudo ipmitool raw 0x28 0x41 1 1
  sleep 1
  RC=$?
  echo "----------------------------------------"
  if [[ $RC -ne 0 ]]; then
    echo -e "\e[31mYafuflash (BIOS) exited with code: $RC\e[0m"
    exit $RC
  fi
  echo -e "\e[32mYafuflash (BIOS) finished successfully (exit code 0).\e[0m"
else
  echo -e "\e[33mBIOS update not required. Skipping.\e[0m"
  
fi

# Step 5: Final message
echo
echo -e "\e[33mIf any component required a power cycle or reboot, please follow on-screen or platform-specific guidance."
echo
echo -e "\e[31m********************************** WARNING: **************************************\e[0m"
echo -e "\e[31m* After the CPLD FW update processed, the system needs AC cycle to take effect.  *\e[0m"
echo -e "\e[31m* Please remove the power cord to perform an AC cycle after all firmware finish  *\e[0m" 
echo -e "\e[31m* updating in order to let the CPLD FW bevalidated.                              *\e[0m"
echo -e "\e[31m**********************************************************************************\e[0m"
echo
echo "[6/6] All completed."
echo "All output (including tools and checks) has been saved to:"
echo "  - $LOG"
echo
echo "End to update at $(date +%T)"
echo
exit 0

