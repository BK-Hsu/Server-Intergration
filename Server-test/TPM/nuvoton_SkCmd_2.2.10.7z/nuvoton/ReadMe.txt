----------------------------------------------------------------------------
Nuvoton Technology Corporation
SkCmd command tool for TPM 
Release Letter
Copyright (c) 2017-2020 Nuvoton Technology Corporation. All Rights Reserved.
----------------------------------------------------------------------------

SkCmd command tool for TPM 1.2 & 2.0 Release Letter
Version:  2.2.10
Date:     Dec 2019

Please read carefully the included End User License Agreement in the
NTC_EULA.txt file.

LICENSE ACKNOWLEDGMENT
----------------------
The following source code components are used to implement parts of the
functionality:
1. SHA1 code � uses code from The Internet Society (2001), Based on Request
   for Comments (RFC) 3174. License agreement:
   http://trustee.ietf.org/license-info
2. SHA2 code � uses code from Olivier Gay <olivier.gay@a3.epfl.ch> including
   FIPS 180-2 SHA-224/256/384/512 implementation.
   License agreement: http://opensource.org/licenses/BSD-3-Clause

For more information please see the copyrights and license agreements as listed
in the LicenseAcknowledgment.txt file.

PACKAGE CONTENTS
----------------
This package contains the following files and subdirectories:
--------------------------+-----------------------------------------------------
Name                      | Description
--------------------------+-----------------------------------------------------
*SkCmd*                   | SkCmd executables (see below)
--------------------------+-----------------------------------------------------
InFiles\                  | Folder containing examples of input ('in') files
--------------------------+-----------------------------------------------------
NTC_EULA.txt              | Nuvoton Software End User License Agreement
--------------------------+-----------------------------------------------------
LicenseAcknowledgment.txt | License Acknowledgement
--------------------------+-----------------------------------------------------
ReadMe.txt                |  This release letter
--------------------------+-----------------------------------------------------

SkCmd executables:
    - wSkCmdx64.exe Windows 64-bit command line SkCmd executable
    - wSkCmdx64.dll Windows 64-bit dynamic link SkCmd library
    - uSkCmdx64.efi UEFI shell 64-bit command line SkCmd executable
    - lSkCmdx64     Linux x64 command line SkCmd executable
    - aSkCmd        Linux ARM command line SkCmd executable

Description
-----------
SkCmd is a command line tool sending TPM commands to TPM device. 
For more information on TPM command parameters and usage see TCG specifications.
Examples are included in the 'InFiles' directory.

For more information about command line SkCmd usage, call the SkCmd from 
OS command prompt with '-h' option. For example in UEFI:
> uSkCmd64.exe -h

Requirements
------------
- Nuvoton NPCT65x or NPCT75x device.

- for wSkCmdx64:
  - Windows with a TBS installed.
  - Installed Visual C++ Redistributable for Visual Studio 2012 (download
    from http://www.microsoft.com/en-us/download/details.aspx?id=30679#)

- for uSkCmdx64:
  - UEFI Shell 2.10 or higher with TPM driver installed.

- for lSkCmdx64:
  - Linux kernel version 2.6.18 or higher, with a TPM driver installed
    in /dev/tpm0
    
- for aSkCmd:
 - Linux kernel version 2.6.18 or higher, with a TPM driver installed
    in /dev/tpm0

Installation
------------
- Copy the files to the target system.

LIMITATIONS
-----------
- Maximum parameter length is 256 characters per parameter.

ENHANCEMENTS
------------
- Add Get Test Result command (-gettestresult/2 options) feedback if error entries are found. 
- Remove DOS and 32-bit executables from the package 

HISTORY
-------
V2.2.7:
-------
- Added aSkCmd executable for ARM Linux
- Added -getekcerts2 option support to read TPM 2.0 EK certificate 
- Set command input buffer limit of 0x800

-----------------------------------------------------------
For contact information see "Contact Us" at www.nuvoton.com
-----------------------------------------------------------
